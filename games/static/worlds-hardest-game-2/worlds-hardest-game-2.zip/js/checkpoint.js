// 20x15
var checkpoints = [
	[],
	// level 1
	[
		[7, 8, 2, 4],
		[19, 8, 2, 4, true]
	],
	
	// level 2
	[
		[7, 6, 3, 2],
		[18, 12, 3, 2, true]
	],
	
	// level 3
	[
		[5, 9, 2, 2, true],
		
	],
	
	// level 4
	[
		[7, 4, 3, 2],
		[18, 14, 3, 2, true]
	],
	
	// level 5
	[
		[12, 9, 4, 2,true]
	],
	
	// level 6
	[
		
		[13, 10, 2, 2, true]
	],
	
	// level 7
	[
		[10, 3, 2, 2],
		[16, 3, 2, 2, true]
	],
	
	// level 8
	[
		[8, 5, 4, 2],
		[16,5,4,2,true]
	],
	
	// level 9
	[
		[7, 5, 2, 2],
		[19, 13, 2, 2, true]
	],
	
	// level 10
	[
		[13, 9, 2, 2, true]
	],
	
	// level 11
	[
		[12, 4, 4, 2],
		[12, 14, 4, 2, true]
	],
	
	// level 12
	[
		[7, 4, 2, 2],
		[19, 14, 2, 2, true]
	],
	
	// level 13
	[
		[7, 4, 3, 2],
		[18, 14, 3, 2, true]
	],
	
	// level 14
	[
		[8, 6, 2, 2],
		[18, 6, 2, 2, true]
	],
	
	// level 15
	[
		[9, 3, 2, 2],
		[19, 3, 2, 2, true]
	],
	
	// level 16
	[
		[7, 5, 4, 2],
		[18, 12, 2, 4, true]
	],
	
	// level 17
	[
		[13, 14, 2, 2, true]
	],
	
	// level 18
	[
		
		[11, 9, 4, 2],
		[9, 5, 2, 2,true]
	],
	
	// level 19
	[
		[4, 9, 3, 2],
		[21, 5, 3, 2],
		[21, 9, 3, 2,true],
        [21, 13, 3, 2]
 		
	],
	
	// level 20
	[
		[10, 5, 2, 1],
		[12, 9, 3, 2, true]
	],
	
	// level 21
	[
	
		[13, 10, 2, 2, true]
	],
	
	// level 22
	[
		[7, 5, 2, 2],
		[19, 13, 2, 2, true]
	],
	
	// level 23
	[
		[4, 8, 2, 4],
		[22, 8, 2, 4, true]
	],
	
	// level 24
	[
		[6, 9, 2, 2],
		
		[9, 3, 2, 2, true],
		[17, 3, 2, 2],
		[20, 9, 2, 2],
		[13, 15, 2, 2]
	],
	
	// level 25
	[
		[10, 14, 2, 2],
		[16, 14, 2, 2, true]
	],
	
	// level 26
	[
		[5, 3, 2, 2, true],
		[5, 6, 2, 2],
		[12, 9, 3, 2],
		[21, 15, 2, 2]
	],
	
	// level 27
	[
		[2, 3, 2, 2],
		[24, 15, 2, 2, true],
		
	],
	
	// level 28
	[
		[13, 3, 2, 2],
		[13, 15, 2, 2,true]
	],
	
	// level 29
	[
		[8, 4, 2, 2],
		[18, 4, 2, 2, true],
		[13, 14, 2, 2]
		
	],
	
	// level 30
	[
		[6, 8, 3, 4],
		[19, 8, 3, 4,true]
		
	],
	// level 31
	[
		[13, 9, 2, 2,true]
		
	],
	// level 32
	[
		[2, 9, 2, 2],
		[24, 9, 2, 2,true]
		
	],
	// level 33
	[
		[4, 8, 2, 4],
		[22,8,2,4,true]
		
	],
	// level 34
	[
		[19, 4, 2, 3],
		[19,13,2,3,true]
		
	],
	// level 35
	[
		[13, 4, 2, 2],
		[13,14,2,2,true]
		
		
	],
	// level 36
	[
		[7, 15, 2, 2],
		[14,9,2,2,true]
		
	],
	// level 37
	[
		[6, 2, 2, 2],
		[20,16,2,2,true]
		
	],
	// level 38
	[
		[4, 5, 2, 2],
		[22,13,2,2,true]
		
	],
	// level 39
	[
		[4, 11, 2, 2],
		[22,7,2,2,true]
	],
	// level 40
	[
		[3, 6, 2, 2],
		[3,12,2,2,true]
		
	],
	// level 41
	[
		[9, 4, 2, 2],
		[17,4,2,2,true]
	],
	// level 42
	[
		[5, 5, 2, 2],
		[5,13,2,2,true]
		
	],
	// level 43
	[
		[5, 9, 2, 2],
		[21,9,2,2,true]
		
	],
	// level 44
	[
		[5, 3, 2, 2],
		[21,15,2,2,true]
		
	],
	// level 45
	[
		[2, 2, 2, 2],
		[4,16,2,2,true]
		
	],
	// level 46
	[
		[5, 9, 2, 2],
		[21,9,2,2,true]
		
		
	],
	// level 47
	[
		[9, 5, 2, 2],
		[17,13,2,2,true]
		
	],
	// level 48
	[
		[2, 9, 2, 2],
		[24,9,2,2,true]
		
	],
	// level 49
	[
		[3, 15, 2, 2],
		[23,3,2,2,true]
		
	],
	// level 50
	[
		[5, 9, 2, 2],
		[21,9,2,2,true]
		
	]
];

function drawChecks() {
	for (var i = 0; i < checkpoints[level].length; i++) {
		canvas.beginPath();
		canvas.rect(
			checkpoints[level][i][0] * cwh(TILE_SIZE) + os.x,
			checkpoints[level][i][1] * cwh(TILE_SIZE) + os.y,
			checkpoints[level][i][2] * cwh(TILE_SIZE),
			checkpoints[level][i][3] * cwh(TILE_SIZE)
		);
		canvas.fillStyle = CHECK_COLOR;
		canvas.fill();
	}
	drawCheckFlash();
}

function drawCheckFlash() {
	if (checkFlashAlpha > 0 && state == "game") {
		canvas.beginPath();
		canvas.rect(
			checkpoints[level][curCheck][0] * cwh(TILE_SIZE) + os.x,
			checkpoints[level][curCheck][1] * cwh(TILE_SIZE) + os.y,
			checkpoints[level][curCheck][2] * cwh(TILE_SIZE),
			checkpoints[level][curCheck][3] * cwh(TILE_SIZE)
		);
		canvas.fillStyle = CHECK_FLASH_COLOR + checkFlashAlpha + ")";
		canvas.fill();
		checkFlashAlpha -= CHECK_FLASH_FADE_SPEED;
	}
}